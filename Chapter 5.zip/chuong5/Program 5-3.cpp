// Chương trình này minh họa một vòng lặp while đơn giản.
#include <iostream>
using namespace std;

int main()
{
    int number = 0;

    while (number < 5)
    {
        cout << "Xin chào\n";
        number++;
    }

    cout << "Đó là tất cả!\n";
    return 0;
}
