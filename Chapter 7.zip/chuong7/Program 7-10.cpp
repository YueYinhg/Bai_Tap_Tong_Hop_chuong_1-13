#include <iostream>
using namespace std;

int main()
{
    // Định nghĩa một mảng các số nguyên.
    int numbers[] = { 10, 20, 30, 40, 50 };

    // Hiển thị các giá trị trong mảng.
    for (int val : numbers)
        cout << val << endl;

    return 0;
}
