#include <iostream>
using namespace std;

int main() {
    int num1 = 2897, num2 = 5, num3 = 837,
        num4 = 34, num5 = 7, num6 = 1623,
        num7 = 390, num8 = 3456, num9 = 12;

    // Hi?n th? h�ng s? ??u ti�n
    cout << num1 << " " << num2 << " " << num3 << endl;

    // Hi?n th? h�ng s? th? hai
    cout << num4 << " " << num5 << " " << num6 << endl;

    // Hi?n th? h�ng s? th? ba
    cout << num7 << " " << num8 << " " << num9 << endl;

    return 0;
}
