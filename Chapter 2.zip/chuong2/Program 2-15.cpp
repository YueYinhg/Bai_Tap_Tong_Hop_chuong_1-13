#include <iostream>
#include <string> // B?t bu?c ?? s? d?ng l?p chu?i (string class).
using namespace std;

int main() {
    string movieTitle;

    movieTitle = "Wheels of Fury"; // G�n gi� tr? "Wheels of Fury" cho bi?n chu?i movieTitle.
    cout << "My favorite movie is " << movieTitle << endl; // In ra m�n h�nh th�ng ?i?p v?i t�n phim y�u th�ch.

    return 0;
}
