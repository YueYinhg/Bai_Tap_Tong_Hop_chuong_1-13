#include <iostream>
using namespace std;

int main() {
    char letter;

    letter = 'A';
    cout << letter << '\n';  // In k� t? 'A' ra m�n h�nh, sau ?� xu?ng d�ng.
    letter = 'B';
    cout << letter << '\n';  // In k� t? 'B' ra m�n h�nh, sau ?� xu?ng d�ng.

    return 0;
}
