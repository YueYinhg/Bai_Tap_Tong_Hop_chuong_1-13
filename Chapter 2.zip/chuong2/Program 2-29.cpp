#include <iostream>
using namespace std;

int main() {
    // Constants
    const double PI = 3.14159;
    const double radius = 5.0;

    // Variable to hold the circumference
    double circumference;

    // Calculate the circumference
    circumference = 2 * PI * radius;

    // Display the circumference
    cout << "The circumference of the circle is: " << circumference << endl;

    return 0;
}
