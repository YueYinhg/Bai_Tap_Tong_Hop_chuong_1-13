#include <iostream>
using namespace std;

int main() {
    int number;  // Khai b�o bi?n number ki?u int

    number = 5;  // G�n gi� tr? 5 cho bi?n number

    cout << "The value in number is " << number << endl;  // In gi� tr? c?a bi?n number

    return 0;
}
