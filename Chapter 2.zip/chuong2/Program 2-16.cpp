#include <iostream>
using namespace std;

int main() {
    float distance;
    double mass;

    distance = 1.495979E11; // G�n kho?ng c�ch t? Tr�i ??t ??n M?t Tr?i
    mass = 1.989E30; // G�n kh?i l??ng c?a M?t Tr?i

    cout << "The Sun is " << distance << " meters away." << endl;
    cout << "The Sun's mass is " << mass << " kilograms." << endl;

    return 0;
}
