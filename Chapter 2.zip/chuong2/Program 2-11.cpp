#include <iostream>
using namespace std;

int main() {
    int floors, rooms, suites;

    floors = 15;
    rooms = 300;
    suites = 30;

    cout << "The Grande Hotel has " << floors << " floors\n";
    cout << "with " << rooms << " rooms and " << suites << " suites.\n";

    return 0;
}
