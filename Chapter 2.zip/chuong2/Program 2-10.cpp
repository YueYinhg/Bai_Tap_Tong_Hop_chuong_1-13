#include <iostream>
using namespace std;

int main() {
    int checking;
    unsigned int miles;
    long days;

    checking = 20;  // Removed the negative sign
    miles = 4276;
    days = 189000;

    cout << "We have made a long journey of " << miles << " miles." << endl;
    cout << "Our checking account balance is " << checking << endl;
    cout << "About " << days << " days ago Columbus ";
    cout << "stood on this spot." << endl;

    return 0;
}
