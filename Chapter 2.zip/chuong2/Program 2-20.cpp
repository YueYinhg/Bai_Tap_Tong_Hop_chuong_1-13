#include <iostream>
using namespace std;

int main() {
    int value = 100; // ??m b?o bi?n value ?� ???c khai b�o v� x�c ??nh tr??c khi s? d?ng.

    cout << value; // B�y gi? kh�ng c�n l?i.

    return 0;
}
