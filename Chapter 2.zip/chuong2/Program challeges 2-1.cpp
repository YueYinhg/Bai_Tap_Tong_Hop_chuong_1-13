#include <iostream>
using namespace std;

int main() {
    int num1 = 50;
    int num2 = 100;
    int total = num1 + num2;

    cout << "The sum of " << num1 << " and " << num2 << " is " << total << endl;

    return 0;
}
