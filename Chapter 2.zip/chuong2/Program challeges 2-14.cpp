#include <iostream>
using namespace std;

int main() {
    cout << "Your name: Your_Name" << endl;
    cout << "Your address: Your_Address, Your_City, Your_State, Your_ZIP_Code" << endl;
    cout << "Your telephone number: Your_Phone_Number" << endl;
    cout << "Your college major: Your_Major" << endl;

    return 0;
}
