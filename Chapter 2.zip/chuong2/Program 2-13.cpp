#include <iostream>
using namespace std;

int main() {
    char letter;

    letter = 65;
    cout << letter << endl;  // K?t qu? l� 'A', v� 65 t??ng ?ng v?i k� t? 'A' trong b?ng m� ASCII.
    letter = 66;
    cout << letter << endl;  // K?t qu? l� 'B', v� 66 t??ng ?ng v?i k� t? 'B' trong b?ng m� ASCII.

    return 0;
}
